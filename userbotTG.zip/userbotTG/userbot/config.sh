touch config.json
clear 
python main.py
python bot.py